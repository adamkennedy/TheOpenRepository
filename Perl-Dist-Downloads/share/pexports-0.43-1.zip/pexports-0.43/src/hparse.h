typedef union {
       char *s;
} YYSTYPE;
#define	ID	258


extern YYSTYPE yylval;
